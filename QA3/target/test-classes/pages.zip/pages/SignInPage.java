package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignInPage {
    private WebDriver driver;

    // Locators
    private By usernameField = By.xpath("//*[@id='Signon']/form/div/label[1]/input");
    private By passwordField = By.xpath("//*[@id='Signon']/form/div/label[2]/input");
    private By submitButton = By.xpath("//*[@id='Signon']/form/div/div/button");
    private By errorMessage = By.xpath("//*[@id='Signon']/form/div/div[2]");

    // Constructor
    public SignInPage(WebDriver driver) {
        this.driver = driver;
    }

    // Actions
    public void enterUsername(String username) {
        driver.findElement(usernameField).clear();
        driver.findElement(usernameField).sendKeys(username);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).clear();
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickSubmit() {
        driver.findElement(submitButton).click();
    }

    public String getErrorMessage() {
        try {
            return driver.findElement(errorMessage).getText();
        } catch (Exception e) {
            return "No error message found.";
        }
    }
}
