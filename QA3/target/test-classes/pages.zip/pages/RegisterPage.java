package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {
    private WebDriver driver;

    // Locators
    private By usernameField = By.xpath("//*[@id='Catalog']/form/table[1]/tbody/tr[1]/td[2]/input");
    private By passwordField = By.xpath("//*[@id='Catalog']/form/table[1]/tbody/tr[2]/td[2]/input");
    private By confirmPasswordField = By.xpath("//*[@id='Catalog']/form/table[1]/tbody/tr[3]/td[2]/input");
    private By submitButton = By.xpath("//*[@id='Catalog']/form/input");

    // Constructor
    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    // Actions
    public void enterUsername(String username) {
        driver.findElement(usernameField).clear();
        driver.findElement(usernameField).sendKeys(username);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).clear();
        driver.findElement(passwordField).sendKeys(password);
    }

    public void confirmPassword(String password) {
        driver.findElement(confirmPasswordField).clear();
        driver.findElement(confirmPasswordField).sendKeys(password);
    }

    public void submitRegistration() {
        driver.findElement(submitButton).click();
    }
}