package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver driver;

    // Locators
    private By signInButton = By.xpath("//*[@id='Menu']/div[1]/a[2]");
    private By registerButton = By.xpath("//*[@id='Menu']/div[1]/a[3]");
    private By cartButton = By.xpath("//*[@id='Menu']/div[2]/a[1]");

    // Constructor
    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    // Actions
    public void clickSignIn() {
        driver.findElement(signInButton).click();
    }

    public void clickRegister() {
        driver.findElement(registerButton).click();
    }

    public void clickCart() {
        driver.findElement(cartButton).click();
    }

    public void navigateToHomePage(String url) {
        driver.get(url);
    }
}