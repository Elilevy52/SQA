package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.junit.Assert.*;
import pages.HomePage;
import pages.SearchPage;

public class SearchTest {
    private WebDriver driver;
    private HomePage homePage;
    private SearchPage searchPage;

    @Before
    public void setUp() {
        driver = new ChromeDriver();
        homePage = new HomePage(driver);
        searchPage = new SearchPage(driver);
        homePage.navigateToHomePage("https://jpetstore.aspectran.com/");
    }

    @Test
    public void testProductSearch() {
        homePage.clickSignIn();
        searchPage.enterSearchQuery("Fish");
        searchPage.clickSearch();
        
        // Validate that the search result contains the word "Fish"
        String pageSource = driver.getPageSource();
        assertTrue("Search result does not contain 'Fish'", pageSource.contains("Fish"));
        System.out.println("Search test passed.");
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
