package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.HomePage;
import pages.RegisterPage;

public class RegisterTest {
    private WebDriver driver;
    private HomePage homePage;
    private RegisterPage registerPage;

    @Before
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        homePage = new HomePage(driver);
        registerPage = new RegisterPage(driver);
        homePage.navigateToHomePage("https://jpetstore.aspectran.com/");
    }

    @Test
    public void testRegistration() {
        homePage.clickRegister();
        registerPage.enterUsername("newUser123");
        registerPage.enterPassword("Password123");
        registerPage.confirmPassword("Password123");
        registerPage.submitRegistration();
        System.out.println("Registration Test Completed.");
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

