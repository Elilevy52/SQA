package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.HomePage;
import pages.SignInPage;

import static org.junit.Assert.assertTrue;

import java.time.Duration;

public class SignInTest {
    private WebDriver driver;
    private HomePage homePage;
    private SignInPage signInPage;

    @Before
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        homePage = new HomePage(driver);
        signInPage = new SignInPage(driver);
        homePage.navigateToHomePage("https://jpetstore.aspectran.com/");
    }

    @Test
    public void testInvalidLogin() {
        System.out.println("Starting Invalid Login Test...");
        homePage.clickSignIn();
        signInPage.enterUsername("wrongUser");
        signInPage.enterPassword("wrongPassword");
        signInPage.clickSubmit();

        String errorMessage = signInPage.getErrorMessage();
        if (errorMessage.contains("Invalid username or password.")) {
            System.out.println("Test Passed: Error message displayed correctly.");
        } else {
            System.out.println("Test Failed: No error message displayed.");
        }
    }

    @Test
    public void testValidLogin() {
        System.out.println("Starting Valid Login Test...");
        homePage.clickSignIn();
        signInPage.enterUsername("j2ee");
        signInPage.enterPassword("j2ee");
        signInPage.clickSubmit();

        // יצירת WebDriverWait להמתנה עד ש-"Sign Out" יופיע
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        boolean isLoggedIn = false;

        try {
            // המתנה עד שכפתור "Sign Out" יופיע
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='Menu']/div[1]/a[4]")));
            isLoggedIn = true;
        } catch (Exception e) {
            isLoggedIn = false;
        }

        if (isLoggedIn) {
            System.out.println("✅ Test Passed: User successfully logged in.");
        } else {
            System.out.println("❌ Test Failed: User did not log in.");
        }
    }


    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
