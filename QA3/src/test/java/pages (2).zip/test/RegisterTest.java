
package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import pages.HomePage;
import pages.RegisterPage;

import static org.junit.Assert.assertTrue;

public class RegisterTest {
    private WebDriver driver;
    private HomePage homePage;
    private RegisterPage registerPage;

    @Before
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        homePage = PageFactory.initElements(driver, HomePage.class);
        registerPage = PageFactory.initElements(driver, RegisterPage.class);
        homePage.navigateToHomePage("https://jpetstore.aspectran.com/");
        homePage.clickRegister();
    }

    @Test
    public void testUserRegistration() {
        System.out.println("Starting User Registration Test...");
        registerPage.enterUsername("newUser123");
        registerPage.enterPassword("Password123");
        registerPage.enterConfirmPassword("Password123");
        registerPage.clickRegister();

        // בדיקה אם ההרשמה הצליחה
        boolean isRegistered = driver.getPageSource().contains("Welcome");
        assertTrue("User did not register successfully", isRegistered);
        if (isRegistered) {
            System.out.println("✅ Test Passed: User successfully registered.");
        } else {
            System.out.println("❌ Test Failed: User did not register.");
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
